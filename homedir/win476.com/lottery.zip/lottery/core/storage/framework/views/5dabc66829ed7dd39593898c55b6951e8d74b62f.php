<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH /home/u786628406/domains/buraqtech.net/public_html/lottery/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>